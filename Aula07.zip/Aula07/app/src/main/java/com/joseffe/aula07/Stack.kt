package com.joseffe.aula07

enum class Stack(val nome: String) {
    FRONTEND("Frontend"),
    BACKEND("Backend"),
    FULLSTACK("Fullstack")
}
