package com.joseffe.aula07

enum class Senioridade(val nome: String) {
    JUNIOR("Junior"),
    PLENO("Pleno"),
    SENIOR("Senior")
}
